# -*- coding: utf-8 -*-

# Copyright (C) 2015 - Benjamin Hebgen
# This program is Free Software see LICENSE file for details

EXEC = "exec"
ARGS = "args"
NAME = "name"
ICON = "icon"
BACKGROUND = "background"
SIDECALLS = "sidecalls"
TYPE = "type"
TYPE_APP = "app"
TYPE_FOLDER = "folder"
ALL_APPS_FOLDER = "all apps"

