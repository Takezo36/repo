__version__ = '0.1.6'

from .ewmh import EWMH
